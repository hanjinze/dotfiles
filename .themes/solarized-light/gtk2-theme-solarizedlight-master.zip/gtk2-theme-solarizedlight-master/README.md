gtk2-theme-solarizedlight
=========================

A GTK2 theme based on the light variant of the [Solarized colorscheme] and [Murrina333].

I found this in a [Pastebin] without any information on the author. If you know who started this, please let me know.

  [solarized colorscheme]: http://ethanschoonover.com/solarized
  [pastebin]: http://pastebin.com/JbYD1pE9
  [murrina333]: http://icedloki.deviantart.com/art/Murrina-333-74797600
